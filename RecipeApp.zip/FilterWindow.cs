﻿namespace RecipeApp
{
    internal class FilterWindow
    {
        public FilterWindow()
        {
        }
    }
}