﻿using System.Windows;

namespace RecipeApp
{
    /// <summary>
    /// Interaction logic for StepsInputDialog.xaml
    /// </summary>
    public partial class StepsInputDialog : Window
    {
        public StepsInputDialog()
        {
            InitializeComponent();
        }
    }
}
