﻿namespace RecipeApp
{
    internal class Recipe
    {
    }
}