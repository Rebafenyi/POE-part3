﻿using System.Windows;

namespace RecipeApp
{
    /// <summary>
    /// Interaction logic for StepsWindow.xaml
    /// </summary>
    public partial class StepsWindow : Window
    {
        public StepsWindow()
        {
            InitializeComponent();
        }
    }
}
